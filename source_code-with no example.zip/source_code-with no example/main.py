import os
import shutil
import cv2 as cv
import numpy as np
import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import filedialog
import ttkbootstrap as ttkboot
from PIL import Image, ImageTk
from ttkbootstrap.constants import *

# ===================== Model =====================
# 程序的业务逻辑和数据


# 将要检测的照片或视频路径以及记录是否要通过摄像头进行识别的标记
image_path, video_path, camera_flag = "", "", False

# 三种识别方法对应的label
image_label, video_label, camera_label = None, None, None

# 三种识别方法中，数据id对应的名称
foundation_identification_names, access_control_inspection_names, criminal_search_names = [], [], []

# 主窗口及其四个分部
root, left_frame, right_top_frame, right_middle_frame, right_bottom_frame = None, None, None, None, None

# 所有的组件
title, left_button1, left_button2, left_button3, left_button4, left_button5, left_button6, combobox, option1, option2, option3, option4, right_button1, right_button2, right_button3 = None, None, None, None, None, None, None, None, None, None, None, None, None, None, None


def apply_font():
    """
    应用设置好的字体样式
    """
    style = ttk.Style()
    style.configure("TButton", font=("SIMHEI", 16), cursor="hand2")
    style.configure("TLabel", font=("SIMHEI", 26))
    style.configure("TRadiobutton", padding=(20, 10), background="#FFFF99", foreground="black", font=("SIMHEI", 20),
                    cursor="hand2")
    style.configure("TCombobox", font=("SIMHEI", 26))
    return None


def combobox_select(event, combobox):
    """
    获取选择style的下拉选择框的选择，并作出回应
    """
    style = ttkboot.Style(theme=combobox.get())  # 更改style
    apply_font()  # 应用字体样式

    return None


def update_selected_option(new_value):
    """
    更新全局变量selected_option的值
    :param new_value: 更新后应为的值
    """
    global selected_option
    selected_option.set(new_value)


def hint_window(width, height, string):
    """
    提示窗口
    :param width: 提示窗口的宽度
    :param height: 提示窗口的高度
    :param string: 提示窗口中需要显示的内容
    """
    new_window = tk.Tk()
    new_window.title("提示")
    new_window.geometry(f"{width}x{height}")
    label = ttk.Label(new_window, text=string, background="#FFFF99", foreground="black", font=("SIMHEI", 20))
    label.pack(side="top", fill="both", expand=True)
    new_window.mainloop()


# “录入训练数据”的相关事件处理函数

def upload_image_sample(path):
    """
    以.jpg图片格式上传样本
    :param path: 要上传的图片样本路径
    """
    # 调用人脸分类器
    face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_frontalface_default.xml")

    # 为即将录入的人脸标记一个id
    face_id = input("请输入将要录入的人脸id（必须是数字）：")
    # 为即将录入的对应id的人脸图片计数
    count = input("请输入将要录入的人脸是相同id下的第几张图片：")  # 由于一次只能上传一张图片，所以这里要求用户自行输入该图片是同id下的第几张图片

    # 导入并读取人脸
    image_sample_path = path
    image_sample = cv.imread(image_sample_path)

    # 转换为灰度图像，便于检测
    gray_image_sample = cv.cvtColor(image_sample, cv.COLOR_BGR2GRAY)

    # 获取图像中的人脸
    faces = face_detector.detectMultiScale(gray_image_sample, 1.3, 5)

    # 读取识别出的所有人脸，找到最大的人脸区域，并在其上绘制矩形区域后存入训练样本
    max_area = 0
    max_face = None
    for x, y, w, h in faces:
        area = w * h
        if area > max_area:
            max_area = area
            max_face = (x, y, w, h)

    # 如果max_face不为空，即图像中有人脸，则绘制矩形
    if max_face:
        # 创建窗口并让其置于最前端
        cv.namedWindow("upload_image_sample", cv.WINDOW_NORMAL)
        cv.setWindowProperty("upload_image_sample", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
        cv.resizeWindow("upload_image_sample", image_sample.shape[1], image_sample.shape[0])

        cv.rectangle(image_sample, (max_face[0], max_face[1]), (max_face[0] + max_face[2], max_face[1] + max_face[3]),
                     (255, 0, 0), thickness=5)
        print("上传效果将在新窗口中显示，请跳转至新窗口查看（按ESC退出新窗口）")
        cv.imshow("upload_image_sample", image_sample)

        # 如果是在基础识别功能中上传样本，那么应该存入基础识别对应的训练集文件夹
        if selected_option.get() == "基础识别":
            cv.imwrite("data\\foundation_identification\\train\\User." + str(face_id) + '.' + str(count) + '.jpg',
                       gray_image_sample[max_face[1]:max_face[1] + max_face[3],
                       max_face[0]:max_face[0] + max_face[2]])
        # 如果是在目标查找功能中上传样本，那么应该存入基础识别对应的训练集文件夹
        elif selected_option.get() == "目标查找":
            cv.imwrite("data\\criminal_search\\train\\User." + str(face_id) + '.' + str(count) + '.jpg',
                       gray_image_sample[max_face[1]:max_face[1] + max_face[3],
                       max_face[0]:max_face[0] + max_face[2]])
        print("图片样本上传成功！")

    while True:
        if cv.waitKey(0) == 27:
            break
    cv.destroyAllWindows()


def upload_video_sample(path):
    """
    以.mp4视频格式上传样本
    :param path: 要上传的视频样本路径
    """
    # 调用人脸分类器
    face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_frontalface_default.xml")

    video_sample_path = path
    video_sample = cv.VideoCapture(path)

    # 为即将录入的人脸标记一个id
    face_id = input("请输入将要录入的人脸id（必须是数字）：")
    # 为即将录入的对应id的人脸图片计数
    count = 0

    print("上传效果将在新窗口中显示，请跳转至新窗口查看（按ESC退出新窗口）")
    while True:
        # flag表示是否成功读取了一帧图像，frame是读取到的图像数据。如果视频播放完毕（flag为False），则退出循环
        flag, frame = video_sample.read()  # 读取视频中的图片

        # 如果视频播放完毕，则退出循环
        if not flag:
            break

        # 灰度处理
        gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

        # 获取图像中的人脸
        faces = face_detector.detectMultiScale(gray_frame, 1.3, 5)

        # 读取识别出的所有人脸，找到最大的人脸区域，并在其上绘制矩形区域后存入训练样本
        max_area = 0
        max_face = None
        for x, y, w, h in faces:
            area = w * h
            if area > max_area:
                max_area = area
                max_face = (x, y, w, h)

        # 如果max_face不为空，即图像中有人脸
        if max_face:
            # 令count递增
            count += 1

            # 绘制矩形并显示图片
            cv.rectangle(frame, (max_face[0], max_face[1]),
                         (max_face[0] + max_face[2], max_face[1] + max_face[3]),
                         (255, 0, 0), thickness=5)

            # 如果是在基础识别功能中上传样本，那么应该存入基础识别对应的训练集文件夹
            if selected_option.get() == "基础识别":
                cv.imwrite(
                    "data\\foundation_identification\\train\\User." + str(face_id) + '.' + str(count) + '.jpg',
                    gray_frame[max_face[1]:max_face[1] + max_face[3],
                    max_face[0]:max_face[0] + max_face[2]])
            # 如果是在目标查找功能中上传样本，那么应该存入基础识别对应的训练集文件夹
            elif selected_option.get() == "目标查找":
                cv.imwrite("data\\criminal_search\\train\\User." + str(face_id) + '.' + str(count) + '.jpg',
                           gray_frame[max_face[1]:max_face[1] + max_face[3],
                           max_face[0]:max_face[0] + max_face[2]])

        # 展示识别过程
        # 创建窗口并让其置于最前端
        cv.namedWindow("upload_video_sample", cv.WINDOW_NORMAL)
        cv.setWindowProperty("upload_video_sample", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
        cv.resizeWindow("upload_video_sample", frame.shape[1], frame.shape[0])

        cv.imshow("upload_video_sample", frame)

        # 如果用户按下ESC，提前退出识别
        if cv.waitKey(1) == 27:
            break

    print("视频样本上传成功！")
    cv.destroyAllWindows()
    video_sample.release()  # 释放视频占用的空间


def upload_camera_sample():
    """
    通过摄像头上传样本
    """
    # 调用人脸分类器
    face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_frontalface_default.xml")

    # 调用摄像头获取样本
    camera_sample = cv.VideoCapture(0)

    # 为即将录入的人脸标记一个id
    face_id = input("请输入将要录入的人脸id（必须是数字）：")
    # 为即将录入的对应id的人脸图片计数
    count = 0

    print("上传效果将在新窗口中显示，请跳转至新窗口查看（按ESC退出新窗口）")
    while True:
        # flag表示是否成功读取了一帧图像，frame是读取到的图像数据。如果视频播放完毕（flag为False），则退出循环
        flag, frame = camera_sample.read()  # 读取摄像头中的图片

        # 如果视频播放完毕，则退出循环
        if not flag:
            break

        # 灰度处理
        gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

        # 获取图像中的人脸
        faces = face_detector.detectMultiScale(gray_frame, 1.3, 5)

        # 读取识别出的所有人脸，找到最大的人脸区域，并在其上绘制矩形区域后存入训练样本
        max_area = 0
        max_face = None
        for x, y, w, h in faces:
            area = w * h
            if area > max_area:
                max_area = area
                max_face = (x, y, w, h)

        # 如果max_face不为空，即图像中有人脸
        if max_face:
            # 令count递增
            count += 1

            # 绘制矩形并显示图片
            cv.rectangle(frame, (max_face[0], max_face[1]),
                         (max_face[0] + max_face[2], max_face[1] + max_face[3]),
                         (255, 0, 0), thickness=5)

            # 将获取到的样本存入门禁识别的训练集文件夹中
            cv.imwrite("data\\access_control_inspection\\train\\User." + str(face_id) + '.' + str(count) + '.jpg',
                       gray_frame[max_face[1]:max_face[1] + max_face[3],
                       max_face[0]:max_face[0] + max_face[2]])

        # 展示识别过程
        # 创建窗口并让其置于最前端
        cv.namedWindow("upload_camera_sample", cv.WINDOW_NORMAL)
        cv.setWindowProperty("upload_camera_sample", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
        cv.resizeWindow("upload_camera_sample", frame.shape[1], frame.shape[0])

        cv.imshow("upload_camera_sample", frame)

        # 如果用户按下ESC，提前退出识别
        if cv.waitKey(10) == 27:
            break

    print("摄像头样本上传成功！")
    cv.destroyAllWindows()
    camera_sample.release()  # 释放视频占用的空间


def upload_sample():
    """
    在四种功能下，“录入训练数据”按钮的事件处理函数
    """
    if selected_option.get() == "基础识别":
        print("基础识别-录入训练数据 ==> 请选择图片或视频文件")
        file_path = filedialog.askopenfilename(title="选择图片或视频文件",
                                               filetypes=[("JPEG files", "*.jpg"), ("MP4 files", "*.mp4"), ])
        # 如果file_path不为空
        if file_path:
            # 如果选择的是.jpg文件，则进入上传图像样本的函数中
            if file_path.endswith(".jpg"):
                print("您选择的是图片文件")
                upload_image_sample(file_path)
            # 如果选择的是.mp4文件，则进入上传是视频样本的函数中
            elif file_path.endswith(".mp4"):
                print("您选择的是视频文件")
                upload_video_sample(file_path)

    elif selected_option.get() == "门禁识别":
        print("门禁识别-录入训练数据 ==> 请通过摄像头录入训练数据")
        upload_camera_sample()

    elif selected_option.get() == "目标查找":
        print("目标查找-录入训练数据 ==> 请选择图片或视频文件")
        file_path = filedialog.askopenfilename(title="选择图片或视频文件",
                                               filetypes=[("JPEG files", "*.jpg"), ("MP4 files", "*.mp4"), ])
        # 如果file_path不为空
        if file_path:
            # 如果选择的是.jpg文件，则进入上传图像样本的函数中
            if file_path.endswith(".jpg"):
                print("您选择的是图片文件")
                upload_image_sample(file_path)
            # 如果选择的是.mp4文件，则进入上传视频样本的函数中
            elif file_path.endswith(".mp4"):
                print("您选择的是视频文件")
                upload_video_sample(file_path)

    elif selected_option.get() == "考场监控":
        hint_window(350, 100, "考场监控无需录入训练数据！")

    return None


# “训练识别模型”的相关事件处理函数

def get_images_and_ids(path):
    """
    从数据集文件夹中获取训练图片及其对应的id
    图片命名格式：User.id.sampleNum
    :param path: 训练集样本所在的文件夹路径
    """

    # 使用列表推导式，获取各个样本的路径列表image_paths
    image_paths = [os.path.join(path, f) for f in os.listdir(path)]

    # 新建两个list用于存放图片和id
    images = []
    ids = []

    # 遍历各个图片路径
    for image_path in image_paths:

        # 检查文件的扩展名是否为 'jpg'，如果不是，跳过此次循环迭代
        if not image_path.endswith(".jpg"):
            continue

        # 将训练集中的灰度图片转化为数组，并存入images
        img = Image.open(image_path)
        img_np = np.array(img, 'uint8')
        images.append(img_np)

        # 获取id并存入ids
        id = int(os.path.split(image_path)[-1].split(".")[1])
        ids.append(id)

    return images, ids


def training_process(path):
    """
    训练模型的过程
    :param path: 训练集样本所在的文件夹路径
    """
    # 初始化识别的方法
    reco = cv.face.LBPHFaceRecognizer_create()

    print("读取训练样本中...")

    images, ids = get_images_and_ids("data\\" + path + "\\train")

    if not (images and ids):
        print("未检测到训练样本！")
        return None

    print("训练样本读取完成！")

    print("训练模型中...")

    # 训练模型
    reco.train(images, np.array(ids))
    # 保存模型
    reco.save("data\\" + path + "\\trainer\\trainer.yml")

    print("训练完成！")


def train_model():
    """
    在四种功能下，“训练识别模型”按钮的事件处理函数
    :return: None
    """
    if selected_option.get() == "基础识别":
        print("基础识别-训练识别模型")
        training_process("foundation_identification")

    elif selected_option.get() == "门禁识别":
        print("门禁识别-训练识别模型")
        training_process("access_control_inspection")

    elif selected_option.get() == "目标查找":
        print("目标查找-训练识别模型")
        training_process("criminal_search")

    elif selected_option.get() == "考场监控":
        hint_window(300, 100, "考场监控无需训练模型！")

    return None


# “照片识别”的相关事件处理函数

def display_image():
    """
    在识别框中展示图片
    """
    # 选择要识别的图片，并记录其路径
    global image_path, image_label
    image_path = filedialog.askopenfilename(title="请选择要进行识别的照片", filetypes=[("JPEG files", "*.jpg")])

    if image_path:
        # 在窗口中展示出要识别的图片

        image = Image.open(image_path)

        # 设置图片大小，使之适应窗口大小
        new_size = (750, 400)
        image.thumbnail(new_size)
        photo = ImageTk.PhotoImage(image)

        # 设置为全局变量，便于清理
        global image_label
        image_label = ttk.Label(right_middle_frame, image=photo)
        image_label.image = photo  # 保持引用，避免被垃圾回收
        image_label.place(x=(763 // 2 - 0.5 * photo.width()), y=(405 // 2 - 0.5 * photo.height()))
        print("照片上传完成，请点击“开始识别”进行识别")


def image_recognition():
    """
    在四种功能下，“照片识别”按钮的事件处理函数
    """

    global image_path
    if selected_option.get() == "基础识别":
        print("基础识别-照片识别")
        clear_process()
        display_image()

    elif selected_option.get() == "门禁识别":
        print("门禁识别-照片识别")
        clear_process()
        display_image()

    elif selected_option.get() == "目标查找":
        print("目标查找-照片识别")
        clear_process()
        display_image()

    elif selected_option.get() == "考场监控":
        clear_process()
        hint_window(350, 100, "考场监控无法进行照片识别！")


# “视频识别”的相关事件处理函数

def display_video():
    """
    在识别框中展示视频的第一帧
    """
    # 选择要识别的视频，并记录其路径
    global video_path, video_label
    video_path = filedialog.askopenfilename(title="请选择要进行识别的照片", filetypes=[("MP4 files", "*.mp4")])

    if video_path:
        # 在窗口中展示出要识别的图片

        video = cv.VideoCapture(video_path)

        # 读取第一帧
        ret, first_frame = video.read()

        # 将 OpenCV 的图片格式转换为 PIL.Image 格式
        first_frame_PIL = Image.fromarray(cv.cvtColor(first_frame, cv.COLOR_BGR2RGB))

        # 设置图片大小，使之适应窗口大小
        new_size = (750, 400)
        first_frame_PIL.thumbnail(new_size)
        photo = ImageTk.PhotoImage(first_frame_PIL)

        video_label = ttk.Label(right_middle_frame, image=photo)
        video_label.image = photo  # 保持引用，避免被垃圾回收
        video_label.place(x=(763 // 2 - 0.5 * photo.width()), y=(405 // 2 - 0.5 * photo.height()))
        print("视频上传完成，请点击“开始识别”进行识别")


def video_recognition():
    """
    在四种功能下，“视频识别”按钮的事件处理函数
    """
    if selected_option.get() == "基础识别":
        print("基础识别-视频识别")
        clear_process()
        display_video()

    elif selected_option.get() == "门禁识别":
        print("门禁识别-视频识别")
        clear_process()
        display_video()

    elif selected_option.get() == "目标查找":
        print("目标查找-视频识别")
        clear_process()
        display_video()

    elif selected_option.get() == "考场监控":
        print("考场监控-视频识别")
        clear_process()
        display_video()


# “摄像头实时识别”的相关事件处理函数

def hint_camera():
    """
    给用户的提示信息
    """
    global right_middle_frame, camera_label
    camera_label = ttk.Label(right_middle_frame, text="当前为摄像头实时识别")
    camera_label.place(x=200, y=180)


def camera_recognition():
    """
    在四种功能下，“摄像头实时识别”按钮的事件处理函数
    """
    global camera_flag, camera_label

    if selected_option.get() == "基础识别":
        print("基础识别-摄像头实时识别")
        clear_process()
        hint_camera()

    elif selected_option.get() == "门禁识别":
        print("门禁识别-摄像头实时识别")
        clear_process()
        hint_camera()

    elif selected_option.get() == "目标查找":
        print("门禁识别-摄像头实时识别")
        clear_process()
        hint_camera()

    elif selected_option.get() == "考场监控":
        print("门禁识别-摄像头实时识别")
        clear_process()
        hint_camera()

    camera_flag = True


# “帮助”的相关事件处理函数

text = None


def scroll_text(*args):
    """
    滑动条Scrollbar的事件处理函数
    """
    global text
    text.yview(*args)


def help():
    """
    在四种功能下，“帮助”按钮的事件处理函数
    """
    global text

    new_window = tk.Tk()
    new_window.title("帮助")

    text = tk.Text(new_window, wrap="word")

    # 创建Scrollbar，并将其绑定到Text
    scrollbar = ttk.Scrollbar(new_window, orient="vertical", command=text.yview)
    text.config(yscrollcommand=scrollbar.set)

    # 定义新的样式标签，并设置字体和大小
    text.tag_configure("custom_font", font=("黑体", 16))

    # 给text中插入文本
    file = open("README.txt", mode='r', encoding='UTF-8')
    long_text = file.readlines()

    # 反转，确保插入时顺序不会发生改变
    reversed_long_text = long_text[::-1]

    # 插入长段文本到 Text 组件中
    for x in reversed_long_text:
        text.insert("1.0", x, "custom_font")

    # 将 Text 组件和 Scrollbar 组件放置在窗口中
    text.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    new_window.mainloop()


# “开始识别”的相关事件处理函数

def low_confidence(id, names, confidence, image, font, x, y, w, h):
    """
    低置信度下对图片的处理函数
    :return: image, 处理后的图像
    """
    confidence = "{0}%".format(round(100 - confidence))

    # 给图像添加文本标签，并绘制矩形
    if selected_option.get() == "基础识别":
        # 读取名称
        name = names[id]

        # 在图像上添加文本标签
        cv.putText(image, str(name), (x + 5, y - 5), font, 1, (0, 0, 255), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (255, 255, 0), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 4)

    elif selected_option.get() == "门禁识别":
        # 读取名称
        name = names[id]

        # 在图像上添加文本标签
        cv.putText(image, str(name), (x + 5, y - 5), font, 1, (0, 255, 0), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (0, 255, 0), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 4)
        print(f"门禁识别通过：{name}")

    elif selected_option.get() == "目标查找":
        # 读取名称
        name = names[id]

        # 在图像上添加文本标签
        cv.putText(image, "!!!  " + str(name) + "  !!!", (x + 5, y - 5), font, 1, (0, 0, 255), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (0, 0, 255), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 4)
        print(f"找到目标：{name}")

    return image


def high_confidence(id, names, confidence, image, font, x, y, w, h):
    """
    高置信度下对图片的处理函数
    :return: image, 处理后的图像
    """
    name = "unknown"
    confidence = "{0}%".format(round(100 - confidence))

    # 给图像添加文本标签，并绘制矩形
    if selected_option.get() == "基础识别":

        # 在图像上添加文本标签
        cv.putText(image, str(name), (x + 5, y - 5), font, 1, (0, 0, 255), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (255, 255, 0), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 4)

    elif selected_option.get() == "门禁识别":

        # 在图像上添加文本标签
        cv.putText(image, str(name), (x + 5, y - 5), font, 1, (0, 0, 255), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (0, 0, 255), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 4)
        print(f"门禁识别未通过：{name}")

    elif selected_option.get() == "目标查找":

        # 在图像上添加文本标签
        cv.putText(image, str(name), (x + 5, y - 5), font, 1, (0, 255, 0), 3)
        cv.putText(image, str(confidence), (x + 5, y + h - 5), font, 1, (0, 255, 0), 3)

        # 在图像上绘制人脸矩形
        cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 4)
        print(f"非目标：{name}")

    return image


def recognition(path):
    """
    识别的过程函数
    :param path: 四种功能对应的文件夹名称
    """
    global image_path, video_path, camera_flag, root
    global foundation_identification_names, access_control_inspection_names, criminal_search_names

    # 如果识别框中有多种样本，提示告知无法识别
    if (image_path and video_path) or (image_path and camera_flag) or (video_path and camera_flag):
        print("不可同时检测多种类型的样本！请清理识别窗口后再试！")
        return None
    # 如果识别框中没有样本，提示告知无法识别
    elif not (image_path or video_path or camera_flag):
        print("未选择识别方法！请点击左侧 照片识别/视频识别/摄像头实时识别 后，再开始识别！")
        return None
    else:
        # ====== 开始识别的准备工作 ======

        # 如果不是附加功能（考场监控），则进入下列分支
        if not selected_option.get() == "考场监控":

            #  如果还没有训练模型
            if not os.path.exists("data\\" + path + "\\trainer\\trainer.yml"):
                print("您尚未训练模型！")
                return None

            # 使用之前训练好的模型（四个功能对应的模型各不相同）
            reco = cv.face.LBPHFaceRecognizer_create()
            reco.read("data\\" + path + "\\trainer\\trainer.yml")

            # 调用人脸分类器，加载特征数据
            face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_frontalface_default.xml")

            # 加载一个字体，用于识别后，在图片上标注出对象的名字
            font = cv.FONT_HERSHEY_SIMPLEX

            id = 0
            # 设置好与id对应的用户名
            names = []
            count = 0

            while True:
                name = input(f"请输入id={count}所对应的名称（输入quit以停止录入）：")
                if name == 'quit':
                    break
                else:
                    names.append(name)
                    count += 1

            print("识别内容将在新窗口展示，请跳转至新窗口查看识别内容（按下ESC键以退出识别窗口）")

            # ====== 正式开始识别 ======

            # 先判断是通过何种途径识别（照片/视频/摄像头），然后再进入分支开始识别
            if image_path:
                # 获取图片
                image = cv.imread(image_path)

                # 计算最小的人脸宽度和高度
                min_w = 0.1 * image.shape[1]
                min_h = 0.1 * image.shape[0]

                # 初始化人名和计数器
                name = names[0]
                count = 0

                # 灰度转换
                gray_image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

                # 人脸框选检测
                faces = face_detector.detectMultiScale(
                    gray_image,
                    scaleFactor=1.2,
                    minNeighbors=5,
                    minSize=(int(min_w), int(min_h))
                )

                for (x, y, w, h) in faces:
                    # 获取识别出的人脸对应的id和置信度confidence
                    id, confidence = reco.predict(gray_image[y:y + h, x:x + w])

                    if count == 1 or count % 30 == 0:
                        if confidence < 60:
                            image = low_confidence(id, names, confidence, image, font, x, y, w, h)

                        else:
                            image = high_confidence(id, names, confidence, image, font, x, y, w, h)

                # 显示图像
                # 创建窗口并让其置于最前端
                cv.namedWindow("image_recognition", cv.WINDOW_NORMAL)
                cv.setWindowProperty("image_recognition", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
                cv.resizeWindow("image_recognition", image.shape[1], image.shape[0])

                cv.imshow('image_recognition', image)

                if cv.waitKey(0) == 27:  # 按下 'ESC' 键退出识别
                    cv.destroyAllWindows()

            elif video_path:
                # 获取视频
                video = cv.VideoCapture(video_path)

                # 计算最小的人脸宽度和高度
                min_w = 0.1 * video.get(3)
                min_h = 0.1 * video.get(4)

                # 初始化人名和计数器
                name = names[0]
                count = 0

                while True:
                    flag, frame = video.read()

                    # 如果视频播放完毕，退出循环
                    if not flag:
                        break

                    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

                    # 人脸框选检测
                    faces = face_detector.detectMultiScale(
                        gray_frame,
                        scaleFactor=1.2,
                        minNeighbors=5,
                        minSize=(int(min_w), int(min_h))
                    )

                    for (x, y, w, h) in faces:
                        # 获取识别出的人脸对应的id和置信度confidence
                        id, confidence = reco.predict(gray_frame[y:y + h, x:x + w])

                        if count == 1 or count % 30 == 0:
                            if confidence < 60:
                                image = low_confidence(id, names, confidence, frame, font, x, y, w, h)

                            else:
                                image = high_confidence(id, names, confidence, frame, font, x, y, w, h)

                    # 显示图像
                    # 创建窗口并让其置于最前端
                    cv.namedWindow("video_recognition", cv.WINDOW_NORMAL)
                    cv.setWindowProperty("video_recognition", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
                    cv.resizeWindow("video_recognition", frame.shape[1], frame.shape[0])

                    cv.imshow('video_recognition', frame)

                    if cv.waitKey(30) == 27:  # 按下 'ESC' 键退出循环
                        break

                # 释放资源
                video.release()
                cv.destroyAllWindows()

            elif camera_flag:
                # 调用摄像头
                cam = cv.VideoCapture(0)

                # 计算最小的人脸宽度和高度
                min_w = 0.1 * cam.get(3)
                min_h = 0.1 * cam.get(4)

                # 初始化人名和计数器
                name = names[0]
                count = 0

                while True:
                    flag, frame = cam.read()

                    # 如果视频播放完毕，退出循环
                    if not flag:
                        break

                    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

                    # 人脸框选检测
                    faces = face_detector.detectMultiScale(
                        gray_frame,
                        scaleFactor=1.2,
                        minNeighbors=5,
                        minSize=(int(min_w), int(min_h))
                    )

                    for (x, y, w, h) in faces:
                        # 获取识别出的人脸对应的id和置信度confidence
                        id, confidence = reco.predict(gray_frame[y:y + h, x:x + w])

                        if count == 1 or count % 30 == 0:
                            if confidence < 60:
                                image = low_confidence(id, names, confidence, frame, font, x, y, w, h)

                            else:
                                image = high_confidence(id, names, confidence, frame, font, x, y, w, h)

                    # 显示图像
                    # 创建窗口并让其置于最前端
                    cv.namedWindow("camera_recognition", cv.WINDOW_NORMAL)
                    cv.setWindowProperty("camera_recognition", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
                    cv.resizeWindow("camera_recognition", frame.shape[1], frame.shape[0])

                    cv.imshow('camera_recognition', frame)

                    if cv.waitKey(30) == 27:  # 按下 'ESC' 键退出循环
                        break

                # 释放资源
                cam.release()
                cv.destroyAllWindows()
        # 如果是附加功能（考场监控），则进入下列分支
        else:
            # 调用侧脸分类器，加载特征数据
            profile_face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_profileface.xml")
            frontal_face_detector = cv.CascadeClassifier("haarcascades\\haarcascade_frontalface_default.xml")

            # 用于接收视频或摄像头获取到的信息
            info = None
            # 最小的人脸宽度和高度
            min_w, min_h = None, None

            if video_path:
                video = cv.VideoCapture(video_path)
                info = video
                min_w, min_h = 0.1 * video.get(3), 0.1 * video.get(4)
            elif camera_flag:
                cap = cv.VideoCapture(0)
                cap.set(3, 640)
                cap.set(4, 480)
                info = cap
                min_w, min_h = 0.1 * cap.get(3), 0.1 * cap.get(4)

            # 疑似作弊次数与判断是否作弊的标记
            suspected_cheating_times, cheating_flag = 0, False

            if not info:
                print("未读取到数据！请清理识别窗口后重试！")
                return None

            while True:
                ret, img = info.read()
                gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
                profile_face_flag, frontal_face_flag = False, False

                # 提取侧脸
                profile_faces = profile_face_detector.detectMultiScale(
                    gray,
                    scaleFactor=1.2,
                    minNeighbors=5,
                    minSize=(int(min_w), int(min_h))
                )

                # 提取正脸
                frontal_faces = frontal_face_detector.detectMultiScale(
                    gray,
                    scaleFactor=1.2,
                    minNeighbors=5,
                    minSize=(int(min_w), int(min_h))
                )

                # 侧脸用红色矩形框出
                for (x, y, w, h) in profile_faces:
                    cv.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 4)
                    roi_gray = gray[y:y + h, x:x + w]
                    roi_color = img[y:y + h, x:x + w]
                    profile_face_flag = True

                # 正脸用绿色矩形框出
                for (x, y, w, h) in frontal_faces:
                    cv.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 4)
                    roi_gray = gray[y:y + h, x:x + w]
                    roi_color = img[y:y + h, x:x + w]
                    frontal_face_flag = True

                # 创建窗口并让其置于最前端
                cv.namedWindow("video", cv.WINDOW_NORMAL)
                cv.setWindowProperty("video", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
                cv.resizeWindow("video", img.shape[1], img.shape[0])
                cv.imshow('video', img)

                # 如果既检测到侧脸，又没有检测到正脸，那么就认为疑似存在作弊行为
                if profile_face_flag and not frontal_face_flag:
                    suspected_cheating_times += 1
                    print("疑似存在作弊行为！")

                # 如果检测到多于3次的疑似作弊行为，则判定为作弊，跳出循环
                if suspected_cheating_times >= 3:
                    cheating_flag = True
                    break

                if cv.waitKey(80) == 27:  # press 'ESC' to quit
                    break

            if cheating_flag:
                info.release()
                cv.destroyAllWindows()
                hint_window(200, 80, "存在作弊行为！")
            else:
                info.release()
                cv.destroyAllWindows()


def start_recognition():
    """
    在四种功能下，“开始识别”按钮的事件处理函数
    """
    if selected_option.get() == "基础识别":
        print("基础识别-开始识别 ==> 请等待系统发出进一步指令...")
        recognition("foundation_identification")

    elif selected_option.get() == "门禁识别":
        print("门禁识别-开始识别 ==> 请等待系统发出进一步指令...")
        recognition("access_control_inspection")

    elif selected_option.get() == "目标查找":
        print("目标查找-开始识别 ==> 请等待系统发出进一步指令...")
        recognition("criminal_search")

    elif selected_option.get() == "考场监控":
        print("考场监控-开始识别 ==> 请等待系统发出进一步指令...")
        recognition("examination_room_monitoring")


# “清理识别窗口”的相关事件处理函数

def clear_process():
    """
    清理识别窗口中已上传的内容，使程序回到任何识别内容都未上传时的状态
    """
    global image_path, image_label, video_path, video_label, camera_flag, camera_label

    if not (image_label == None or not image_label.winfo_exists()):
        image_label.destroy()
    if not (video_label == None or not video_label.winfo_exists()):
        video_label.destroy()
    if not (camera_label == None or not camera_label.winfo_exists()):
        camera_label.destroy()

    image_path = ""
    video_path = ""
    camera_flag = False


def clear_recognition():
    """
    在四种功能下，“清理识别窗口”按钮的事件处理函数
    """
    if selected_option.get() == "基础识别":
        print("基础识别-清理识别窗口")
    elif selected_option.get() == "门禁识别":
        print("门禁识别-清理识别窗口")
    elif selected_option.get() == "目标查找":
        print("目标查找-清理识别窗口")
    elif selected_option.get() == "考场监控":
        print("考场监控-清理识别窗口")

    clear_process()


# “测试摄像头”的相关事件处理函数

def test_camera_process():
    """
    测试摄像头功能
    """
    print("请稍候...正在打开摄像头...")
    cap = cv.VideoCapture(0)
    cap.set(3, 640)  # 设置摄像头测试窗口的宽度
    cap.set(4, 480)  # 设置摄像头测试窗口的高度

    print("按ESC退出测试")
    while True:
        ret, frame = cap.read()
        # 如果成功读取帧
        if ret:
            # 显示原始图像和灰度图像
            # 创建窗口并让其置于最前端
            cv.namedWindow("frame", cv.WINDOW_NORMAL)
            cv.setWindowProperty("frame", cv.WND_PROP_TOPMOST, 1)  # 将窗口置顶
            cv.resizeWindow("frame", frame.shape[1], frame.shape[0])

            cv.imshow('frame', frame)  # 显示原始图像

            # 等待用户按键，如果按下 'ESC' 键（ASCII码为27），退出循环
            if cv.waitKey(30) == 27:
                break
        else:
            break

    # 释放摄像头资源，关闭所有显示窗口
    cap.release()
    cv.destroyAllWindows()


def test_camera():
    """
    在四种功能下，“测试摄像头”按钮的事件处理函数
    """
    if selected_option.get() == "基础识别":
        print("基础识别-测试摄像头")
    elif selected_option.get() == "门禁识别":
        print("门禁识别-测试摄像头")
    elif selected_option.get() == "目标查找":
        print("目标查找-测试摄像头")
    elif selected_option.get() == "考场监控":
        print("考场监控-测试摄像头")
    test_camera_process()


# ===================== View =====================
# 显示用户界面


def split_frame():
    """
    将大窗口root分割为四个小frame
    :return: 四个小frame
    """
    global root, left_frame, right_top_frame, right_middle_frame, right_bottom_frame
    # 左边栏
    left_frame = ttk.Frame(root, width=246, height=566, borderwidth=2, relief="solid")
    left_frame.place(x=5, y=5)

    # 右上侧边栏
    right_top_frame = ttk.Frame(root, width=763, height=72, borderwidth=2, relief="solid")
    right_top_frame.place(x=256, y=5)

    # 右中侧边栏
    right_middle_frame = ttk.Frame(root, width=763, height=412, borderwidth=2, relief="solid")
    right_middle_frame.place(x=256, y=82)

    # 右下侧边栏
    right_bottom_frame = ttk.Frame(root, width=763, height=72, borderwidth=2, relief="solid")
    right_bottom_frame.place(x=256, y=499)


def create_component():
    """
    在每个小frame中创建组件
    """
    apply_font()

    global selected_option
    global left_frame, right_top_frame, right_middle_frame, right_bottom_frame
    global title, left_button1, left_button2, left_button3, left_button4, left_button5, left_button6, combobox, option1, option2, option3, option4, right_button1, right_button2, right_button3, right_button4

    # ==== 应用标题 ====
    title = ttk.Label(left_frame, text="人脸识别系统", style="TLabel")
    title.place(x=10, y=20)

    # ==== 按钮 ====
    left_button1 = ttk.Button(left_frame, text="录入训练数据", style="TButton", command=upload_sample)
    left_button1.place(x=42, y=100)

    left_button2 = ttk.Button(left_frame, text="训练识别模型", style="TButton", command=train_model)
    left_button2.place(x=42, y=166)

    left_button3 = ttk.Button(left_frame, text="照片识别", style="TButton", command=image_recognition)
    left_button3.place(x=65, y=232)

    left_button4 = ttk.Button(left_frame, text="视频识别", style="TButton", command=video_recognition)
    left_button4.place(x=65, y=298)

    left_button5 = ttk.Button(left_frame, text="摄像头实时识别", style="TButton", command=camera_recognition)
    left_button5.place(x=33, y=364)

    left_button6 = ttk.Button(left_frame, text="帮助", style="TButton", command=help)
    left_button6.place(x=88, y=430)

    right_button1 = ttk.Button(right_bottom_frame, text="开始识别", style="TButton", command=start_recognition)
    right_button1.place(x=85, y=18)

    right_button2 = ttk.Button(right_bottom_frame, text="清理识别窗口", style="TButton", command=clear_recognition)
    right_button2.place(x=295, y=18)

    right_button3 = ttk.Button(right_bottom_frame, text="测试摄像头", style="TButton", command=test_camera)
    right_button3.place(x=545, y=18)

    # ==== 下拉组合框 ====
    style_option = ["cosmo", "flatly", "journal", "litera", "lumen", "minty", "pulse", "sandstone", "united", "yeti",
                    "morph", "simplex", "cerculean", "solar", "superhero", "darkly", "cyborg", "vapor"]
    combobox = ttk.Combobox(left_frame, values=style_option)
    combobox.place(x=38, y=500)
    combobox.set("自定义主题样式")
    combobox.bind("<<ComboboxSelected>>", lambda event: combobox_select(event, combobox))

    # ==== 单选框 ====
    selected_option = tk.StringVar(value="基础识别")  # 用于跟踪选中的选项，初始默认为“基础识别”
    option1 = ttk.Radiobutton(right_top_frame, text="基础识别", variable=selected_option, value="基础识别",
                              command=lambda: update_selected_option("基础识别"))
    option2 = ttk.Radiobutton(right_top_frame, text="门禁识别", variable=selected_option, value="门禁识别",
                              command=lambda: update_selected_option("门禁识别"))
    option3 = ttk.Radiobutton(right_top_frame, text="目标查找", variable=selected_option, value="目标查找",
                              command=lambda: update_selected_option("目标查找"))
    option4 = ttk.Radiobutton(right_top_frame, text="考场监控", variable=selected_option, value="考场监控",
                              command=lambda: update_selected_option("考场监控"))

    option1.place(x=16, y=10)
    option2.place(x=201, y=10)
    option3.place(x=386, y=10)
    option4.place(x=571, y=10)

    return None


# ===================== Controller =====================
# 处理用户输入，协调模型和视图之间的交互

def controller():
    """
    处理用户输入，协调模型和视图之间的交互
    """
    # 创建主页面并设置默认主题样式
    global root
    root = tk.Tk()
    root.title("人脸识别系统")
    root.geometry("1024x576")
    style = ttkboot.Style(theme="morph")  # 默认主题样式为morph

    # 将root分割为多个小frame
    global left_frame, right_top_frame, right_middle_frame, right_bottom_frame
    split_frame()

    # 在每个小frame中创建组件
    create_component()

    # 开始运转
    root.mainloop()

    return None


if __name__ == '__main__':
    controller()
